import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public class HuffmanTree {

    private TreeNode root;
    private PriorityQueue<TreeNode> pq;
    private int numNodesWithVal;
    private int[] freq;

    /**
     * Make a new huffman tree
     */
    public HuffmanTree() {
        this(new TreeNode(-1, 0));
    }

    /**
     * One parameter constructor that makes huffman tree
     * @param node root node of the huffman tree
     */
    public HuffmanTree(TreeNode node) {
        root = node;
        pq = new PriorityQueue<>();
        numNodesWithVal = 0;
    }

    /**
     * Gets the number of nodes with value of the huffman tree
     * @return number of nodes with value of huffman tree
     */
    public int getNumNodesWithVal() {
        return numNodesWithVal;
    }

    /**
     * Adds each value to the priority queue as TreeNodes
     * @param vals sorted set of character values
     * @param freq array of frequencies associated with the values
     */
    public void makeQueue(TreeSet<Integer> vals, int[] freq) {
        for (int val : vals) {
            //make a tree node with number & frequency pairs
            TreeNode temp = new TreeNode(val, freq[val]);
            pq.enqueue(temp);
        }
        // add a tree node with pseudo eof data
        pq.enqueue(new TreeNode(IHuffConstants.PSEUDO_EOF, 1));
    }

    /**
     * Makes a huffman tree using the priority queue
     */
    public void makeTree() {
        while (pq.size() > 1) {
            //take first two elements from queue, combine into one node
            TreeNode n1 = pq.front();
            pq.dequeue();
            TreeNode n2 = pq.front();
            pq.dequeue();
            pq.enqueue(new TreeNode(n1, n1.getFrequency() + n2.getFrequency(), n2));
        }

        //root is the last node left
        root = pq.front();
    }

    /**
     * Gets a map with values and paths to values
     * @return a map with values and paths to values
     */
    public Map<Integer, String> returnMap() {
        Map<Integer, String> map = new HashMap<>();
        makeMap(root, "", map);
        return map;
    }

    /**
     * Map helper method that puts node values with a string of 0s and 1s as the path
     * @param node current TreeNode
     * @param path the path to the current TreeNode
     * @param map stores node values and path strings as key-value pairs
     */
    public void makeMap(TreeNode node, String path, Map<Integer, String> map) {
        if (node.isLeaf()) {
            //add path to map with TreeNode value as key
            map.put(node.getValue(), path);
        } else {
            //recursive call to check left and right subtrees
            makeMap(node.getLeft(), path + "0", map);
            makeMap(node.getRight(), path + "1", map);
        }
    }

    /**
     * Gets the number of bits in huffman tree
     * @return number of bits in huffman tree
     */
    public int getTreeBits() {
        return bitsHelper(root);
    }

    /**
     * Determines the number of bits in the tree
     * @param node current TreeNode being looked at
     * @return number of bits in the tree
     */
    public int bitsHelper(TreeNode node) {
        if (node.isLeaf()) {
            //add extra bit for the pseudo EOF char
            return 2 + IHuffConstants.BITS_PER_WORD;
        }
        //recurse through left and right subtrees
        return 1 + bitsHelper(node.getLeft()) + bitsHelper(node.getRight());
    }

    /**
     * Gets the total number of nodes in huffman tree
     * @return number of nodes in huffman tree
     */
    public int numNodes() {
        return countNodes(root, new int[1])[0];
    }

    /**
     * Count the number of nodes in the tree
     * @param node current node in the tree
     * @param count total nodes in the tree
     * @return array that holds number of nodes in the tree
     */
    public int[] countNodes(TreeNode node, int[] count) {
        if (node != null) {
            if (!node.isLeaf()) {
                //empty leaf so only increment count
                count[0]++;
            } else {
                //increase num nodes when it's a leaf
                count[0]++;
                numNodesWithVal++;
            }
            //recurse through left and right subtrees
            count = countNodes(node.getLeft(), count);
            count = countNodes(node.getRight(), count);
        }
        return count;
    }

    /**
     * Gets the number of bits written
     * @param bitOut the BitOutputStream to write to
     * @return number of bits written
     */
    public int traverseTree(BitOutputStream bitOut) {
        return traverseHelper(bitOut, root, new int[1])[0];
    }

    /**
     * Helper that writes tree header and counts num bits written
     * @param bitOut BitOutputStream object to write to
     * @param node current TreeNode
     * @param count number of bits that have been written
     * @return array of one integer containing num of bits written
     */
    public int[] traverseHelper(BitOutputStream bitOut, TreeNode node, int[] count) {
        if (node != null) {
            if (!node.isLeaf()) {
                //write one bit with value equal to 0
                bitOut.writeBits(1, 0);
                count[0]++;
            } else {
                //node is leaf so write 1 bit and value of leaf bits
                bitOut.writeBits(1, 1);
                bitOut.writeBits(IHuffConstants.BITS_PER_WORD + 1, node.getValue());
                count[0] += IHuffConstants.BITS_PER_WORD + 2;
            }
            //recurse through left and right subtrees
            count = traverseHelper(bitOut, node.getLeft(), count);
            count = traverseHelper(bitOut, node.getRight(), count);
        }
        return count;
    }

    /**
     * Rebuilds all necessary info from standard count heading
     * @param bitIn BitInputStream object to read from
     * @return new modified frequencies array
     * @throws IOException
     */
    public int[] rebuildCounts(BitInputStream bitIn) throws IOException {
        freq = new int[IHuffConstants.ALPH_SIZE + 1];
        //rebuild frequencies and priority queue
        for (int i = 0; i < IHuffConstants.ALPH_SIZE; i++) {
            int val = bitIn.readBits(IHuffConstants.BITS_PER_INT);
            freq[i] = val;
            //check frequency for every ascii value and add to pq if it's in file
            if (val > 0) {
                pq.enqueue(new TreeNode(i, val));
            }
        }
        freq[IHuffConstants.ALPH_SIZE] = 1;
        pq.enqueue(new TreeNode(IHuffConstants.PSEUDO_EOF, 1));

        //remake tree
        makeTree();
        return freq;
    }

    /**
     * Rebuilds the Huffman Tree
     * @param bitIn BitInputStream to read from
     * @return the rebuilt huffman tree
     * @throws IOException
     */
    public HuffmanTree rebuildTree(BitInputStream bitIn) throws IOException {
        return new HuffmanTree(rebuildHelper(bitIn));
    }

    /**
     * Remakes all necessary info from standard tree heading
     * @param bitIn BitInputStream to read from
     * @return root of the rebuilt tree
     * @throws IOException
     */
    public TreeNode rebuildHelper(BitInputStream bitIn) throws IOException {
        int bit = bitIn.readBits(1);
        if (bit == 1) {
            return new TreeNode(bitIn.readBits(IHuffConstants.BITS_PER_WORD + 1), 0);
        } else {
            TreeNode temp = new TreeNode(-1, 0);
            temp.setLeft(rebuildHelper(bitIn));
            temp.setRight(rebuildHelper(bitIn));
            return temp;
        }
    }

    /**
     * Processes the encoded data and writes it to an un-huffed stream
     * @param bitIn the BitInputStream to read from
     * @param bitOut the BitOutputStream to write to
     * @return the number of bits written
     * @throws IOException
     */
    public int decode(BitInputStream bitIn, BitOutputStream bitOut) throws IOException {
        int count = 0;
        TreeNode temp = root;
        boolean done = false;
        int bit = bitIn.readBits(1);
        if (bit == -1) {
            throw new IOException("Error reading compressed file. \n" +
                    "unexpected end of input. No PSEUDO_EOF value.");
        } else {
            // keep reading while we have not reached pseudo EOF value
            while (temp != null && !done) {
                if (temp.isLeaf()) {
                    int val = temp.getValue();
                    if (val == IHuffConstants.PSEUDO_EOF) {
                        done = true;
                    } else {
                        // if next val is not pseudo EOF, write to uncompressed file
                        bitOut.writeBits(IHuffConstants.BITS_PER_WORD, val);
                        count += IHuffConstants.BITS_PER_WORD;
                        // place temp node back at root
                        temp = root;
                    }
                }
                //left if bit is 0 or right if bit is 1
                if (bit == 0) {
                    temp = temp.getLeft();
                } else {
                    temp = temp.getRight();
                }
                bit = bitIn.readBits(1);
            }
        }
        return count;
    }
}
