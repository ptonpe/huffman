/*  Student information for assignment:
 *
 *  On <MY|OUR> honor, <NAME1> and <NAME2), this programming assignment is <MY|OUR> own work
 *  and <I|WE> have not provided this code to any other student.
 *
 *  Number of slip days used:
 *
 *  Student 1 (Student whose Canvas account is being used)
 *  UTEID:
 *  email address:
 *  Grader name:
 *
 *  Student 2
 *  UTEID:
 *  email address:
 *
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.TreeSet;

public class SimpleHuffProcessor implements IHuffProcessor {

    private IHuffViewer myViewer;
    private IHuffViewer viewer;
    private int[] freq;
    private TreeSet<Integer> vals;
    private int bitDif;
    private HuffmanTree tree;
    private Map<Integer, String> map;
    private int format;

    /**
     * Preprocess data so that compression is possible ---
     * count characters/create tree/store state so that
     * a subsequent call to compress will work. The InputStream
     * is <em>not</em> a BitInputStream, so wrap it int one as needed.
     * @param in is the stream which could be subsequently compressed
     * @param headerFormat a constant from IHuffProcessor that determines what kind of
     * header to use, standard count format, standard tree format, or
     * possibly some format added in the future.
     * @return number of bits saved by compression or some other measure
     * Note, to determine the number of
     * bits saved, the number of bits written includes
     * ALL bits that will be written including the
     * magic number, the header format number, the header to
     * reproduce the tree, AND the actual data.
     * @throws IOException if an error occurs while reading from the input file.
     */
    public int preprocessCompress(InputStream in, int headerFormat) throws IOException {
        //showString("Not working yet");
        format = headerFormat;
        freq = new int[ALPH_SIZE + 1];
        vals = new TreeSet<>();
        makeFreqs(in);

        //build huffman tree
        tree = new HuffmanTree();
        tree.makeQueue(vals, freq);
        tree.makeTree();

        // build map with paths and vals
        map = tree.returnMap();

        int original = originalBits();
        int compressed = compressedBits();
        bitDif = original - compressed;
        return bitDif;
    }

    /**
     * Makes an array of frequencies of bits as integers
     * @param in InputStream object
     * @throws IOException if an error occurs while reading from the input file
     */
    private void makeFreqs(InputStream in) throws IOException {
        BitInputStream bits = new BitInputStream(in);
        int temp = bits.readBits(BITS_PER_WORD);
        while (temp != -1) {
            //increase frequency of char in array of integers
            freq[temp]++;
            vals.add(temp);
            temp = bits.readBits(BITS_PER_WORD);
        }

        //set frequency of pseudo EOF
        freq[ALPH_SIZE] = 1;
        bits.close();
    }

    /**
     * Calculates number of bits in original file
     * @return number of bits in original file
     */
    private int originalBits() {
        int count = 0;
        for (int i = 0; i < ALPH_SIZE; i++) {
            count += freq[i] + BITS_PER_WORD;
        }
        return count;
    }

    /**
     * Calculates the number of bits in compressed file
     * @return number of bits in compressed file
     */
    private int compressedBits() {
        int count = 0;
        //add bits for magic number and header constant
        count += BITS_PER_INT * 2;
        if (format == STORE_TREE) {
            //32 bit representation of tree size plus bits for nodes
            count += BITS_PER_INT + tree.getTreeBits();
        } else if (format == STORE_COUNTS) {
            //bits needed to store the array
            count += ALPH_SIZE * BITS_PER_INT;
        }
        //add actual compressed bits
        for (int val : map.keySet()) {
            String path = map.get(val);
            count += path.length() * freq[val];
        }
        return count;
    }

    /**
	 * Compresses input to output, where the same InputStream has
     * previously been pre-processed via <code>preprocessCompress</code>
     * storing state used by this call.
     * <br> pre: <code>preprocessCompress</code> must be called before this method
     * @param in is the stream being compressed (NOT a BitInputStream)
     * @param out is bound to a file/stream to which bits are written
     * for the compressed file (not a BitOutputStream)
     * @param force if this is true create the output file even if it is larger than the input file.
     * If this is false do not create the output file if it is larger than the input file.
     * @return the number of bits written.
     * @throws IOException if an error occurs while reading from the input file or
     * writing to the output file.
     */
    public int compress(InputStream in, OutputStream out, boolean force) throws IOException {
        if (!force && bitDif < 0) {
            throw new IOException("Compressed file has " + (-1 * bitDif) + " more bits "
                    + "than uncompressed file. Select \"force compression\" option to compress.");
        }
        int bitCount = 0;
        BitInputStream bis = new BitInputStream(in);
        BitOutputStream bos = new BitOutputStream(out);

        //write bits for magic number and format
        bos.writeBits(BITS_PER_INT, MAGIC_NUMBER);
        bos.writeBits(BITS_PER_INT, format);
        bitCount += BITS_PER_INT * 2;

        //write headers depending on format
        bitCount += writeHeader(bos);
        int temp = bis.readBits(BITS_PER_WORD);
        while (temp != -1) {
            String path = map.get(temp);
            bitCount += write(bos, path);

            //move to next char
            temp = bis.readBits(BITS_PER_WORD);
        }
        //find bits for pseudo eof and add to bitCount
        bitCount += write(bos, map.get(PSEUDO_EOF));
        bis.close();
        bos.close();
        return bitCount;
    }

    /**
     * Writes header of compressed file based on format
     * @param bos BitOutputStream object to write to
     * @return number of bits being written
     */
    private int writeHeader(BitOutputStream bos) {
        int count = 0;
        if (format == STORE_COUNTS) {
            for (int i = 0; i < ALPH_SIZE; i++) {
                //write frequency of each char
                bos.writeBits(BITS_PER_INT, freq[i]);
                count += BITS_PER_INT;
            }
        } else {
            //write tree size based on num nodes with value
            int size = (tree.getNumNodesWithVal() * (BITS_PER_WORD + 2))
                    + (tree.numNodes() - tree.getNumNodesWithVal());
            bos.writeBits(BITS_PER_INT, size);
            count += tree.traverseTree(bos);
        }
        return count;
    }

    /**
     * Writes given String in bits
     * @param bos BitOutputStream object to write to
     * @param str string to write
     * @return number of bits written
     */
    private int write(BitOutputStream bos, String str) {
        for (int i = 0; i < str.length(); i++) {
            String subStr = str.substring(i, i + 1);
            //write bits one at a time
            bos.writeBits(1, Integer.parseInt(subStr));
        }
        return str.length();
    }

    /**
     * Uncompress a previously compressed stream in, writing the
     * uncompressed bits/data to out.
     * @param in is the previously compressed data (not a BitInputStream)
     * @param out is the uncompressed file/stream
     * @return the number of bits written to the uncompressed file/stream
     * @throws IOException if an error occurs while reading from the input file or
     * writing to the output file.
     */
    public int uncompress(InputStream in, OutputStream out) throws IOException {
	        int count = 0;
            BitInputStream bin = new BitInputStream(in);
            BitOutputStream bout = new BitOutputStream(out);

            //make sure file starts with magic number
            int magic = bin.readBits(BITS_PER_INT);
            if (magic != MAGIC_NUMBER) {
                myViewer.showError("Error reading compressed file. \n" +
                        "File did not start with the");
                bin.close();
                bout.close();
                return -1;
            }

            //determine header format
            format = bin.readBits(BITS_PER_INT);

            //rebuild information from header
            tree = new HuffmanTree();
        if (format == STORE_COUNTS) {
            freq = tree.rebuildCounts(bin);
        } else if (format == STORE_TREE) {
            //read size of tree
            bin.readBits(BITS_PER_INT);
            tree = tree.rebuildTree(bin);
        }
        //uncompress rest of the data
        count += tree.decode(bin, bout);
        bin.close();
        bout.close();
        return count;
    }

    public void setViewer(IHuffViewer viewer) {
        myViewer = viewer;
    }

    private void showString(String s){
        if (myViewer != null) {
            myViewer.update(s);
        }
    }
}
