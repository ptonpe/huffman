import java.util.LinkedList;
import java.util.Iterator;

public class PriorityQueue<E extends Comparable<? super E>> {

    private LinkedList<E> q;

    /**
     * Makes a new priority queue
     */
    public PriorityQueue() {
        q = new LinkedList<>();
    }

    /**
     * Adds given data into the priority queue dealing with ties fairly
     * @param data data to be added to the queue
     * @return true once data is added
     */
    public boolean enqueue(E data) {
        if (data == null) {
            throw new IllegalArgumentException("Precondition violated: " +
                    "enqueue. data cannot be null.");
        }
        //empty LL just add
        if (size() == 0) {
            q.add(data);
            return true;
        }
        int count = 0;
        boolean found = false;
        Iterator<E> it = q.iterator();

        //iterate through LL looking for add point
        while (it.hasNext() && !found) {
            E curr = it.next();
            int cmp = data.compareTo(curr);
            if (cmp >= 0) {
                count++;
            } else {
                found = true;
            }
        }
        // add data at specified index
        q.add(count, data);
        return true;
    }

    /**
     * Removes the first element in from the priority queue assuming non-empty
     * @return true if queue is changed after calling this method, false otherwise
     */
    public boolean dequeue() {
        if (size() != 0) {
            q.removeFirst();
            return true;
        }
        return false;
    }

    /**
     * Removes all elements from the priority queue
     */
    public void clear() {
        q.clear();
    }

    /**
     * Gets the number of elements in the priority queue
     * @return num elements in priority queue
     */
    public int size() {
        return q.size();
    }

    /**
     * Gets first element in the priority queue
     */
    public E front() {
        if (size() != 0) {
            return q.getFirst();
        }
        return null;
    }

    /**
     * Checks whether the priority queue contains elements
     * @return true if queue is empty, false otherwise
     */
    public boolean isEmpty() {
        return size() == 0;
    }

    /**
     * Checks whether priority queue contains this Object
     * @param obj object being searched for
     * @return true if queue contains object, false otherwise
     */
    public boolean contains(Object obj) {
        return q.contains(obj);
    }

    /**
     * Makes string representation of the priority queue
     * @return the string representation of the queue
     */
    public String toString() {
        return q.toString();
    }

}
